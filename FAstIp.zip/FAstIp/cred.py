#Twilio Details

account_sid = 'AC16a948c3a950e25dd8e6060f87cf8172'
auth_token = 'bf4c4b21871f154475dd6a2b70d40036'
twilionumber = '+19108124952'
twiliosmsnumber = '+19108124952'

#FC Bot
API_TOKEN="8035961144:AAFhNjE9ULbMl11QWewI_yhpiFjfW-NaH18"

#Host URL
callurl = 'https://1efe-2404-7c00-52-467e-187c-f547-6a12-6b82.ngrok-free.app'
twiliosmsurl = 'https://1efe-2404-7c00-52-467e-187c-f547-6a12-6b82.ngrok-free.app/sms'









